﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneLoader : MonoBehaviour
{

     public void LoadNextScene()
    {
        //Loads student question scene
        int currentSceneIndex = SceneManager.GetActiveScene().buildIndex;
        SceneManager.LoadScene(currentSceneIndex + 1);
    }

    public void LoadTeacherScene()
    {
        //Loads teacher question scene
        int currentSceneIndex = SceneManager.GetActiveScene().buildIndex;
        SceneManager.LoadScene(2);//
    }

    public void toMenuScreen()
    {
        //Goes back to main menu
        SceneManager.LoadScene(0);
    }

}
